declare module 'sodium-native';
